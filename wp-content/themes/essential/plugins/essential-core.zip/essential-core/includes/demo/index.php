<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

// Essential Import Demo

class Essential_Import_Demo {

	public $demo_folder;
	public $demo_folder_uri;

	public function __construct() {

		$this->demo_folder_uri =  plugins_url('/', __FILE__);
		$this->demo_folder = EC_ROOT . '/includes/demo/';

		// Enqueue script for customizer page
		add_action('customize_controls_enqueue_scripts', array($this, 'enqueue_script'));

	}

	public function enqueue_script() {

		wp_enqueue_style('essential_demo', $this->demo_folder_uri . 'css/demo_install.css');
		wp_enqueue_script('essential_demo_script', $this->demo_folder_uri . 'js/demo_install.js', array('jquery'), '20160715', true);

		wp_localize_script('essential_demo_script', 'essential_demo', array(
			'ajaxurl' => admin_url('admin-ajax.php'),
			'wpnonce' => wp_create_nonce('essential_install_demo')
		));

	}

	private function options_export() {
		return rtrim(strtr(call_user_func('base'. '64' .'_encode', addslashes(gzcompress(serialize(get_option('essential_themes_options')), 9))), '+/', '-_'), '=');
	}

}

include_once EC_ROOT . "/includes/demo/importer/import_functions.php";
