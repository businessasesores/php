;(function ($, window, document, undefined) {
	'use strict';

	var Shortcodes = vc.shortcodes;

   _.extend(vc.atts, {
		vc_efa_chosen: {
			parse:function (param) {
				var value = this.content().find('.wpb_vc_param_value[name=' + param.param_name + ']').val();
				return (value) ? value.join(',') : '';
			}
		}
   });

})(jQuery, window, document);
