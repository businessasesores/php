<?php

/*

Plugin Name: Essential Core

Plugin URI: https://themeforest.net/item/essential-responsive-minimal-one-page-wordpress-theme/19732646

Author: Riccardo Borchi

Author URI: https://www.riccardoborchi.it/

Version: 2.0

Description: Includes Portfolio Custom Post Type and WPBakery Page Builder Shortcodes

Text Domain: essential

*/

defined('EC_ROOT') or define('EC_ROOT', dirname(__FILE__));
defined('EC_VERSION') or define('EC_VERSION', '1.0');

if(!class_exists('Essential_Core')) {

	require_once EC_ROOT . '/composer/custom_icon.php';
	require_once EC_ROOT . '/composer/font-class.php';
	require_once EC_ROOT . '/includes/helpers.php';
	require_once EC_ROOT . '/includes/custom-post-type.php';
	include_once EC_ROOT . '/includes/demo/index.php';

	// Include Kirki Framework
	include_once EC_ROOT . '/includes/kirki/kirki.php';

	// Include Default Options
	include_once EC_ROOT . '/includes/options-theme.php';

	class Essential_Core {

		private $assets_js;
		private $assets_css;

		public function __construct() {

			$this->assets_js  = plugins_url('/composer/js', __FILE__);
			$this->assets_css = plugins_url('/composer/css', __FILE__);

			add_action('admin_print_scripts-post.php', array($this, 'vc_enqueue_scripts'), 99);
			add_action('admin_print_scripts-post-new.php', array($this, 'vc_enqueue_scripts'), 99);
			add_action('admin_init', array($this, 'essential_load_shortcodes'));
			add_action('wp', array($this, 'essential_load_shortcodes'));

		}

		// Load Shortcodes

		public function essential_load_shortcodes() {

			if(class_exists('Vc_Manager')) {

				foreach (glob(EC_ROOT . '/' . 'shortcodes/essential_*.php') as $shortcode) {
					require_once(EC_ROOT . '/' . 'shortcodes/' . basename($shortcode));
				}

				foreach (glob(EC_ROOT . '/' . 'shortcodes/vc_*.php') as $shortcode) {
					require_once(EC_ROOT . '/' . 'shortcodes/' . basename($shortcode));
				}

				foreach (glob(EC_ROOT . '/shortcodes/*', GLOB_ONLYDIR) as $shortcode) {
					require_once(EC_ROOT . '/' . 'shortcodes/' . basename($shortcode) . "/" . basename($shortcode) . ".php");
				}

				require_once EC_ROOT . '/composer/params.php';

				require_once EC_ROOT . '/composer/init.php';

			}

		}

		public static function essential_plugin_dir() {
			return plugin_dir_path(__FILE__);
		}

		// Enqueue Scripts

		public function vc_enqueue_scripts() {
			wp_enqueue_script('vc-script', $this->assets_js . '/vc-script.js', array('jquery'), '1.0.0', true);
			wp_enqueue_style('rs-vc-custom', $this->assets_css . '/vc-style.css' );
		}

		// Enqueue CSS

		public function assets_css($param) {
			return $this->assets_css . '/' . $param;
		}

	}

	new Essential_Core;

}

// After VC Init

add_action('init', 'vc_remove_components');

function vc_remove_components() {

   // Remove VC Elements
   if(function_exists('vc_remove_element')) {

		vc_remove_element('vc_cta');
		vc_remove_element('revision');
		vc_remove_element('attachment');
		vc_remove_element('nav_menu_item');
		vc_remove_element('booked_appointments');
		vc_remove_element('vc4_templates');
		vc_remove_element('customize_changeset');
		vc_remove_element('mc4wp-form');

   }

}
